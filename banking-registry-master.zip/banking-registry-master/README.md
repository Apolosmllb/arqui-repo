# Spring Cloud Registry Service
Spring Cloud Registry Service

# Registry Service (Eureka)
http://localhost:8761