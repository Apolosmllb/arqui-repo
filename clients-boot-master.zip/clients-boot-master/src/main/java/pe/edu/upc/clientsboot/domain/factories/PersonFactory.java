package pe.edu.upc.clientsboot.domain.factories;

public class PersonFactory {
}
