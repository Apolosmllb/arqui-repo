package pe.edu.upc.clientsboot.application.enums;

public enum ResultType {
    SUCCESS,
    FAILURE
}