package pe.edu.upc.clientsboot.config;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

//@Configuration
//@EnableSwagger2
public class SwaggerConfig {
    /*@Bean
    public Docket api() {
        return new Docket(DocumentationType.SWAGGER_2)
            .tags(new Tag("Clients", "Clients"))
            .select()
            .apis(RequestHandlerSelectors.any())
            .paths(PathSelectors.any())
            .build();
    }*/
}
