package pe.edu.upc.clientsboot;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ClientsBootApplicationTests {

	@Test
	void contextLoads() {
	}

}
