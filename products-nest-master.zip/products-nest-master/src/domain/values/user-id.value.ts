import { IdNumber } from "./id-number.value";

export class UserId extends IdNumber {
}