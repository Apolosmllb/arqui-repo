export enum ProductStateEnum {
  INACTIVE = 0,
  ACTIVE = 1,
}