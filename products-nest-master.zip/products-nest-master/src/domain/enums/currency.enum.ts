export enum Currency {
  SOLES = 'SOL',
  DOLARES = 'USD',
  EUROS = 'EUR'
}