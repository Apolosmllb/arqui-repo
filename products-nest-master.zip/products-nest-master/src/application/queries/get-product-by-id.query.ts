export class GetProductByIdQuery {
  public constructor(
    public readonly productId: number) {}
}