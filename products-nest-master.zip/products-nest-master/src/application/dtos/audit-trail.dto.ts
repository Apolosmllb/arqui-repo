export class AuditTrailDto {
  public createdAt: string;
  public createdBy: number;
  public updatedAt: string;
  public updatedBy: number;
}