# Spring Cloud Gateway Service
Spring Cloud Gateway Service

# API Gateway Service
http://localhost:8080