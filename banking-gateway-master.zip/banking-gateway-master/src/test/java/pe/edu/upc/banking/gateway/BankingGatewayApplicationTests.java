package pe.edu.upc.banking.gateway;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BankingGatewayApplicationTests {

	@Test
	void contextLoads() {
	}

}
