# Banking - Net Core 3.1 - NServiceBus
Banking - Net Core 3.1 - NServiceBus
 
# ENVIRONMENT VARIABLES
## MYSQL_BANKING_CORE_NSB
```
Data Source={YOUR-HOST};Port=3306;Database={YOUR_DATABASE};User Id={YOUR-USER};Password={YOUR_PASSWORD}
```

## RABBITMQ_BANKING_NSB_CORE
```
amqp://{YOUR-USER-VHOST}:{YOUR-PASSWORD}@{HOST}/{YOUR-USER-VHOST}
```