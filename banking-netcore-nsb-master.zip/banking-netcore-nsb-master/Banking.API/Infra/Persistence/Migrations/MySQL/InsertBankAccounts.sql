﻿INSERT INTO bank_account(bank_account_id, number, balance, currency, bank_account_state_id, customer_id, created_at_utc, updated_at_utc)
VALUES
('892b7679-f1a0-4afd-ad84-9325d1d8e58a', '1234567891', 2000, 'USD', 1, '12c9164f-1aa6-464b-842e-385844e482ff', UTC_TIMESTAMP(), UTC_TIMESTAMP()),
('21ed0807-58d8-41db-a890-ef5b38f6aec5', '1234567892', 0, 'USD', 1, '12c9164f-1aa6-464b-842e-385844e482ff', UTC_TIMESTAMP(), UTC_TIMESTAMP());