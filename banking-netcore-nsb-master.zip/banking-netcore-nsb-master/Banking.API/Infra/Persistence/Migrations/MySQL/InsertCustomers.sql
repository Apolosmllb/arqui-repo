﻿INSERT INTO customer(customer_id, first_name, last_name, is_active, created_at_utc, updated_at_utc) 
VALUES
('12c9164f-1aa6-464b-842e-385844e482ff', 'Juan', 'Pérez', 1, UTC_TIMESTAMP(),UTC_TIMESTAMP()),
('b18aa3af-5aa8-4bd7-8c6b-adbc52c16407', 'Carlos', 'Pérez', 1, UTC_TIMESTAMP(),UTC_TIMESTAMP()),
('62e027c9-d04e-4b96-a22d-a50dba97cd07', 'Alberto', 'Otero', 1, UTC_TIMESTAMP(),UTC_TIMESTAMP());