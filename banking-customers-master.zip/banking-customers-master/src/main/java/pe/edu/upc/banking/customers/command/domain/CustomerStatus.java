package pe.edu.upc.banking.customers.command.domain;

public enum CustomerStatus {
    ACTIVE,
    INACTIVE
}