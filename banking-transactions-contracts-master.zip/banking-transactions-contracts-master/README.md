# Transactions Microservice Messages
```
$ mvn -v
$ mvn clean package
$ mvn install:install-file -Dfile=/users/efrain/documents/workspace-upc/axon-banking/banking-transactions-contracts/target/banking-transactions-contracts-0.0.1.jar -DgroupId=pe.edu.upc -DartifactId=banking-transactions-contracts -Dversion=0.0.1 -Dpackaging=jar
```