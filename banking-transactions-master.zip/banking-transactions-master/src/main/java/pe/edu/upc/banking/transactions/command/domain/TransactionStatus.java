package pe.edu.upc.banking.transactions.command.domain;

public enum TransactionStatus {
        CREATED,
        IN_PROGRESS,
        FAILED,
        COMPLETED
}