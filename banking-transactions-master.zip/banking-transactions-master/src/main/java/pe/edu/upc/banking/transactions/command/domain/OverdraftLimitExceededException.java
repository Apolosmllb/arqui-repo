package pe.edu.upc.banking.transactions.command.domain;

public class OverdraftLimitExceededException extends Exception {
}