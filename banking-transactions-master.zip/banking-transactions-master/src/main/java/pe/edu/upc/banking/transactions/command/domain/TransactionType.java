package pe.edu.upc.banking.transactions.command.domain;

public enum TransactionType {
	DEPOSIT, WITHDRAW, TRANSFER
}