# Banking Common
```
$ mvn clean package
$ mvn install:install-file -Dfile=path-to-jar -DgroupId=com.decompiler -DartifactId=jd-core-java -Dversion=0.0.1 -Dpackaging=jar
$ mvn install:install-file -Dfile=/users/efrain/documents/workspace-upc/axon-banking/banking-common/target/banking-common-0.0.1.jar -DgroupId=pe.edu.upc -DartifactId=banking-common -Dversion=0.0.1 -Dpackaging=jar
```