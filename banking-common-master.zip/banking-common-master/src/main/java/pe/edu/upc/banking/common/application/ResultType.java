package pe.edu.upc.banking.common.application;

public enum ResultType {
    SUCCESS,
    FAILURE
}