export const CustomAmplifyTheme = {
  button: {
    backgroundColor: 'green',
    alignItems: 'center',
    padding: 16,
  },
};

export default CustomAmplifyTheme;
